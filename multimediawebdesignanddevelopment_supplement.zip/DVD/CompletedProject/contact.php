<!DOCTYPE html>
<html>
	<head>
	<title>Contact Page</title>
	</head>
	<body>
		<?php 
			// This will process and display the myname field
			$_POST["myname"] = substr($_POST["myname"], 0, 50);
			$unsafe = array(";","'","\"","&","\\");
			$_POST["myname"] = string_replace($unsafe, "", $_POST["myname"]);
			$_POST["myname"] = strip_tags($_POST["myname"]);

			echo $_POST["myname"];
		?>
	</body>
</html>
