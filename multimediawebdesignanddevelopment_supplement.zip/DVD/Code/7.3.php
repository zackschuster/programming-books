<!DOCTYPE html>
<html>
	<head>
	<title>My PHP Page</title>
	</head>
	<body>
		<?php
			$mytext = "Hello, PHP!" . PHP_EOL;
			echomytext;
		?>
	</body>
</html>
