for (var x = 0; x < 5; x = x + 1) {
	// These are statements that will execute when the condition is true
	alert(x + 1);
}
