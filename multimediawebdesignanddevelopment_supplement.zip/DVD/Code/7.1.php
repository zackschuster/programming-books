<!DOCTYPE html>
<html>
	<head>
	<title>My PHP Page</title>
	</head>
	<body>
		<?php
			echo"Hello, PHP!";
		?>
	</body>
</html>
