function phoneDisplay() {
	if (document.getElementById("pref_phone").checked) {
		document.getElementById("phone_div").innerHTML = "Phone Number: <input type=\"text\" name=\"phone\">";
	} else {
		document.getElementById("phone_div").innerHTML = "";	
	}
}
