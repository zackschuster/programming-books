function validateContact() {
	�
if (document.contact.myname.value.length<= 0) {
		errDisplay("name_err","The name field cannot be empty.");
		okay = false;	
	}
�
}
