functionerrDisplay(elementID,message) {
	document.getElementById(elementID).innerHTML = message;
}

functionvalidateContact() {
�
}
