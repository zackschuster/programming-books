var x = 0;
while (x < 5) {
	// These are statements that will execute when the condition is true
	alert(x + 1);
	x = x + 1; // This is the statement to update the condition
}
