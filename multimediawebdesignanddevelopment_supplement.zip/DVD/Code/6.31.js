function validateContact() {
	�
if (document.contact.myname.value.length <= 0) {
		document.getElementById("name_err").innerHTML = "The name field cannot be empty.";
		okay = false;	
	}
�
}
