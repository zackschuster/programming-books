function validateContact() {
	var okay = true;	
�
if (!document.getElementById("pref_email").checked && !document.getElementById("pref_phone").checked) {
	alert("A preferred method of contact must be selected.");
	okay = false;
}
return okay;
}
