$hostaddress = "hostaddress";
$username = "username";
$password = "password";
$link = mysql_connect($hostaddress, $username, $password);
if (!$link) {
	// This is the fail case for the connection...
}
