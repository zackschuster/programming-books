<!DOCTYPE html>
<html>
	<head>
	<title>Contact Page</title>
	</head>
	<body>
		<?php
			// This will process and display the myname field
$_POST["myname"] = substr($_POST["myname"], 0, 50);
$unsafe = array(";","'","\"","&","\\");
$_POST["myname"] = string_replace($unsafe, "", , $_POST["myname"]);
$_POST["myname"] = strip_tags($_POST["myname"]);

			echo $_POST["myname"];

$headers   = 'MIME-Version: 1.0' . '\r\n';
$headers .= 'Content-type: text/html; charset=iso-8859-1' . '\r\n';
$headers .= 'From: Theodor Richardson <noreply@wherever.com>' . '\r\n';
$mailme = mail('to.address@wherever.com', 'Contact Entry Information', 'The name field is ' . $_POST["myname"], $headers);
		?>
	</body>
</html>
