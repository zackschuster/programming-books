$headers   = 'MIME-Version: 1.0' . '\r\n';
$headers .= 'Content-type: text/html; charset=iso-8859-1' . '\r\n';
$headers .= 'From: Theodor Richardson <noreply@wherever.com>' . '\r\n';
