CREATE TABLE 'your_schema_name_here', 'zippy' (
	'submission' VARCHAR(25) NOT NULL,
	'email' VARCHAR(50) NOT NULL,
	'salutation' VARCHAR(50) NOT NULL,
	'name' VARCHAR(50) NOT NULL,
	'method' VARCHAR(50) NOT NULL,
	'phone' VARCHAR(150) NOT NULL,
	'subscribe' BOOL NOT NULL,
	'message' TEXT NOT NULL,
) ENGINE = MYSIAM COMMENT = 'Zippy Beans Contact Form'
