$submission_date = date("m/d/y H:i:s");
$query = "INSERT INTO zippy (submission, email, salutation, name, method, phone, message) VALUES ('" . $submission_date . "', '" . $_POST['email']) ."','" . $_POST['salutation'] . "','" . $_POST['name'] . "','" . $_POST['preference'] . "','" . $_POST['phone'] . "','" . $_POST['message'] . "')";

$result = mysql_query($query);	
