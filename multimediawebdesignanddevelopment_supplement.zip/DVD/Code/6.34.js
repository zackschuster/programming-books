function validateContact() {
	var okay = true;
	errDisplay("name_err","");
	errDisplay("email_err","");
	errDisplay("method_err","");
	errDisplay("message_err","");
�
}
