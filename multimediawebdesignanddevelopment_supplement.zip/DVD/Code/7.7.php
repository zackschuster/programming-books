$unsafe = array(";","'","\"","&","\\");
$_POST["myname"] = string_replace($unsafe, "", $_POST["myname"]);
