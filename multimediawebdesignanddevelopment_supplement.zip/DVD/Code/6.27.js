function validateContact() {
	var okay = true;	
�
varat_position = document.contact.email.value.indexOf('@');
vardot_position = document.contact.email.value.lastIndexOf('.');
varemail_length = document.contact.email.value.length;
if (((at_position< 1)||(dot_position< 1))||((dot_position + 2) >email_length)) {
	alert("The email address entered is not valid.");
		okay = false;
	}	
return okay;
}
