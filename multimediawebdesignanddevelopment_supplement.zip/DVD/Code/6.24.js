function validateContact() {
	if (document.contact.myname.value.length<= 0) {
		alert("The name field cannot be empty.");
		return false;	
	}
	if (document.contact.email.value.length<= 0) {
		alert("The email field cannot be empty.");
		return false;	
	}
	if (document.contact.message.value.length<= 0) {
		alert("The message field cannot be empty.");
		return false;	
	}
return true;
}
