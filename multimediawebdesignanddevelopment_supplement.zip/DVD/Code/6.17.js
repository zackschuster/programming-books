switch (variable) {
	case 'A': // Note that the case is a literal value
		// This will execute if the variable == 'A'
		break; // This stops execution from moving to the next case
	case 'B':
		// This will execute if the variable == 'B'
		break; // This stops execution from moving to the next case		
	default:
		// This will execute if no other case matchesd the variable
		break; // This is not necessary, but it is good coding practice 
}
