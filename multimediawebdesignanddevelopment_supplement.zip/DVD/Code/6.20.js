var x = 0;
do {
	/* These are statements that will execute once and will repeat if the condition is true */
	alert(x + 1);
	x = x + 1; // This is the statement to update the condition
} while (x < 5); // This will determine the condition for continuation
