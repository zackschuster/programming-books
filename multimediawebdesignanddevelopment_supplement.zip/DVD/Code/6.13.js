if (condition) {
	// These are statements that will execute only if condition is true
}
