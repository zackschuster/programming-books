$submission_date = date("m/d/y H:i:s");
$query = "SELECT name, message FROM zippy WHERE submission = '" . $submission_date . "' AND email = '" . $_POST['email']) ."'";

$result = mysql_query($query);	
$row = mysql_fetch_array($result);
