function validateContact() {
	var okay = true;	
�
	var pattern = /;|'|"|&|\\/g;
	if (pattern.test(document.contact.myname.value)) {
		alert("The name field contains invalid characters. These include & ; ' \" and \\.");
		okay = false;
	}
returnokay;
}
