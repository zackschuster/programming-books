if (condition) {
	// These are statements that will execute only if the condition is true
} else {
	// These are statements that will execute only if the condition is false

}
