$hostaddress = "hostaddress";
$username = "username";
$password = "password";
$link = mysql_connect($hostaddress, $username, $password);
