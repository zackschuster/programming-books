if (condition1) {
	// These are statements that will execute only if condition1 is true
} else if (condition2) {
	/* These are statements that will execute only if condition1 is false and condition 2 is true */
} else {
	/* These are statements that will execute only if condition1 and condition2 are false */
}
