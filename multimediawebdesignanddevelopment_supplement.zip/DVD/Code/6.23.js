function validateContact() {
	if (document.contact.myname.value.length <= 0) {
		alert("The name field cannot be empty.");
		return false;	
	}
return true;
}
