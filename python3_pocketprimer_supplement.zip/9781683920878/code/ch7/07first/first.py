import pygame
pygame.init()
surf = pygame.display.set_mode((400, 400))
pygame.display.update()
input()
