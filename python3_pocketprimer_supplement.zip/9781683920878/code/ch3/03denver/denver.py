city = input()
if city < "Denver":
    print ("The name given comes before Denver in an alphabetic list")
elif city > "Denver":
    print ("The name given comes after Denver in an alphabetic list")
else:
    print ("The name given was Denver")
