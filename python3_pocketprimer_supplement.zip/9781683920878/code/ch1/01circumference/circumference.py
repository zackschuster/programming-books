print ("This program calculates the circumference of a circle.")
radius = input ("Enter the radius of the circle: ")
radius = float(radius)
circ = radius *2.0 * 3.1415926
print ("The circumference is ", circ)