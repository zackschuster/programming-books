#!/bin/bash

inputfile="namepairs.csv"
outputfile="reversenames.csv"
fnames="fnames"
lnames="lnames"

cat $inputfile|cut -d"," -f1 > $fnames
cat $inputfile|cut -d"," -f2 > $lnames

#this works from the command line but not here:
paste –d',' $lnames $fnames > $outputfile
