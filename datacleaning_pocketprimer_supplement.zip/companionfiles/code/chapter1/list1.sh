cp abc.sh		def.sh  
cp abc2.sh	def2.sh
cp abc3.sh	def3.sh
