for f in `ls *py`
do
  echo "file is: $f"
done

