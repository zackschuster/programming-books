export x="123"
echo "inside abc.sh" 
echo "x = $x"

