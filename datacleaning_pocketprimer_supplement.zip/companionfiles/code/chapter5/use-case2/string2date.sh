inputfile="dates.txt"

cat $inputfile | awk '
{
   print substr($0,1,4)"-"substr($0,5,2)"-"substr($0,7,2)" "substr($0,9,2)":"substr($0,11,2)":"substr($0,13,2) 
}
'

