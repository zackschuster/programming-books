import tensorflow as tf

a1 = tf.range(3, 18, 3)
a2 = tf.range(0, 8, 2)
a3 = tf.range(-6, 6, 3)
a4 = tf.range(-10, 10, 4)

print('a1:',a1) 
print('a2:',a2)
print('a3:',a3)
print('a4:',a4)

