/***********************************************************
A tabled Prolog program in B-Prolog for the eight puzzle.
by Neng-Fa Zhou, March 2012.
***********************************************************/

go:-
    init_state(S0,R0,C0),
    goal_state(Sn,_,_),
    plan(S0,Sn,R0,C0,Plan,_),
    writeln(plan(Plan)).


% the initial state:
%  1   2   3 
%  4   5   6  
%  7   8   _  
init_state(S0,3,3):-
    S0 = [t(1,1,1), t(2,1,2), t(3,1,3), t(4,2,1),t(5,2,2), t(6,2,3), t(7,3,1),t(8,3,2)].

% the goal state:
%  _   1   2 
%  3   4   5
%  6   7   8

goal_state(Sn,1,1):-
    Sn = [t(1,1,2), t(2,1,3), t(3,2,1), t(4,2,2), t(5,2,3), t(6,3,1), t(7,3,2),t(8,3,3)].

:-table plan(+,+,+,+,-,min).
plan(S,S,_,_,Plan,Len):-!,Plan=[],Len=0.
plan(S0,S,R0,C0,[Dir|Plan],Len):-
    moves(S0,S,R0,C0,Moves),
    member(move(_,Dir,R1,C1,S1),Moves),
    plan(S1,S,R1,C1,Plan,Len1),
    Len is Len1+1.

moves(S0,S,R0,C0,Moves):-
    move(up,S0,S,R0,C0,Moves1,Moves2),
    move(down,S0,S,R0,C0,Moves2,Moves3),
    move(left,S0,S,R0,C0,Moves3,Moves4),
    move(right,S0,S,R0,C0,Moves4,[]),
    sort(Moves1,Moves).  % sort the moves by Mahanttan distance

move(up,S0,S,R0,C0,Moves,MovesR):-
    R1 is R0-1,
    (R1 >= 1 ->
     update(S0,R0,C0,R1,C0,S1),
     manhattan_dist(S1,S,0,Dist),
     Moves=[move(Dist,up,R1,C0,S1)|MovesR]
     ;
     Moves=MovesR
    ).
move(down,S0,S,R0,C0,Moves,MovesR):-
    R1 is R0+1,
    (R1 =< 3 ->
     update(S0,R0,C0,R1,C0,S1),
     manhattan_dist(S1,S,0,Dist),
     Moves=[move(Dist,down,R1,C0,S1)|MovesR]
     ;
     Moves=MovesR
    ).
move(left,S0,S,R0,C0,Moves,MovesR):-
    C1 is C0-1,
    (C1 >= 1 ->
     update(S0,R0,C0,R0,C1,S1),
     manhattan_dist(S1,S,0,Dist),
     Moves=[move(Dist,left,R0,C1,S1)|MovesR]
     ;
     Moves=MovesR
    ).
move(right,S0,S,R0,C0,Moves,MovesR):-
    C1 is C0+1,
    (C1 =< 3 ->
     update(S0,R0,C0,R0,C1,S1),
     manhattan_dist(S1,S,0,Dist),
     Moves=[move(Dist,right,R0,C1,S1)|MovesR]
     ;
     Moves=MovesR
    ).
    
% Move the empty square from (R0,C0) to (R1,C1),
% this means to move the tile at (R1,C1) to (R0,C0)
update([t(TNo,R1,C1)|S0],R0,C0,R1,C1,S):-!,
    S=[t(TNo,R0,C0)|S0].
update([Tile|Tiles],R0,C0,R1,C1,[Tile|S]):-
    update(Tiles,R0,C0,R1,C1,S).

manhattan_dist([],_,Dist,Dist).
manhattan_dist([t(_,R1,C1)|S1],[t(_,R2,C2)|S2],Dist0,Dist):-
    Dist1 is Dist0+abs(R1-R2)+abs(C1-C2),
    manhattan_dist(S1,S2,Dist1,Dist).
