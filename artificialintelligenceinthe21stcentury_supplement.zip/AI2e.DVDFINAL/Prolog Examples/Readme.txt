This folder contains several examples in B-Prolog. 

set.pl          --- implementation of set operations.
farmer.pl       --- program for the farmer-goat-sheep-cabbage puzzle.
water.pl        --- program for the water jugs puzzle.
eightPuzzle.pl  --- program for the eight puzzle.

These examples utilize some of the B-Prolog-specific features such as 
finite-domain constraints, arrays, declarative loops, and tabling. 

B-Prolog is available at

                        www.probp.com

and more information about B-Prolog can be found in the following articles:

Neng-Fa Zhou, "The Language Features and Architecture of B-Prolog", 
Theory and Practice of Logic Programming, Special issue on Prolog systems, 
vol. 12, no. 1-2, pp. 189-218, 2012.

Neng-Fa Zhou, Salvador Abreu, and Ulrich Neumerkel, "How to Solve it With 
B-Prolog", ALP Newsletter, 2011.
